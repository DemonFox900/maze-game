var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the player Sofia
var Sofia =createSprite(20,25,18,18)
Sofia.shapeColor="Black"
//creating the maze walls (wall1 - wall2)
  var wall1=createSprite(105,100,200,45)
  var wall2=createSprite(250,20,200,20)
  var wall3=createSprite(240,50,100,15)
  var wall4=createSprite(220,170,20,55)
  var wall5=createSprite(1,150,350,50)
  var wall6=createSprite(250,100,80,35)  
  var wall7=createSprite(1,220,250,70) 
  var wall8=createSprite(340,90,30,50)  
  var wall9=createSprite(350,200,100,50)  
  var wall10=createSprite(250,270,245,20)  
  var wall11=createSprite(0,300,20,19)  
  var wall12=createSprite(10,300,20,19)  
  var wall13=createSprite(20,300,20,19)  
  var wall14=createSprite(30,300,20,19)  
  var wall15=createSprite(40,300,20,19)  
  var wall16=createSprite(50,300,20,19)
  var wall17=createSprite(60,300,20,19) 
  var wall18=createSprite(350,320,250,20)
  var wall19=createSprite(1,340,300,10)
  var wall20=createSprite(100,390,199,49)
  var wall21=createSprite(200,370,250,3)  
  var wall22=createSprite(325,370,10,10) 
//create cup
var cup=createSprite(400,365,20,50)
cup.shapeColor="White"

wall1.shapeColor="Orange"
wall2.shapeColor="Orange"
wall3.shapeColor="Orange"
wall4.shapeColor="Orange"
wall5.shapeColor="Orange"
wall6.shapeColor="Orange"
wall7.shapeColor="Orange"
wall8.shapeColor="Orange"
wall9.shapeColor="Orange"
wall10.shapeColor="Orange"
wall11.shapeColor="Orange"
wall12.shapeColor="Orange"
wall13.shapeColor="Orange"
wall14.shapeColor="Orange"
wall15.shapeColor="Orange"
wall16.shapeColor="Orange"
wall17.shapeColor="Orange"
wall18.shapeColor="Orange"
wall19.shapeColor="Orange"
wall20.shapeColor="Orange"
wall21.shapeColor="Orange"
wall22.shapeColor="Orange"
function draw() {
  //setting the background color to pink
  background("Blue");
if(Sofia.collide(cup)){
  background("White")
}

if(keyDown(UP_ARROW)){
Sofia.velocityX=0
Sofia.velocityY=-5
}

if (keyDown(DOWN_ARROW)){

Sofia.velocityX=0
Sofia.velocityY=+5
}

if(keyDown(RIGHT_ARROW)){

Sofia.velocityX=+5
Sofia.velocityY=0
}
if(keyDown(LEFT_ARROW)){
Sofia.velocityX=-5
Sofia.velocityY=0
}

createEdgeSprites()
Sofia.bounceOff(edges)
Sofia.bounceOff(wall1)
Sofia.bounceOff(wall2)
Sofia.bounceOff(wall3)
Sofia.bounceOff(wall4)
Sofia.bounceOff(wall5)
Sofia.bounceOff(wall6)
Sofia.bounceOff(wall7)
Sofia.bounceOff(wall8)
Sofia.bounceOff(wall9)
Sofia.bounceOff(wall10)
Sofia.bounceOff(wall11)
Sofia.bounceOff(wall12)
Sofia.bounceOff(wall13)
Sofia.bounceOff(wall14)
Sofia.bounceOff(wall15)
Sofia.bounceOff(wall16)
Sofia.bounceOff(wall17)
Sofia.bounceOff(wall18)
Sofia.bounceOff(wall19)
Sofia.bounceOff(wall20)
Sofia.bounceOff(wall21)
Sofia.bounceOff(wall22)































drawSprites();

}






































function resetSofia()
{
  Sofia.bounceOff(wall1);
Sofia.bounceOff(wall2);
Sofia.bounceOff(wall3);
Sofia.bounceOff(wall4);
Sofia.bounceOff(wall5);
Sofia.bounceOff(wall6);
Sofia.bounceOff(wall7);
Sofia.bounceOff(wall8);
Sofia.bounceOff(wall9);
Sofia.bounceOff(wall10);
Sofia.bounceOff(wall11);
Sofia.bounceOff(wall12);
Sofia.bounceOff(wall13);
Sofia.bounceOff(wall14);
Sofia.bounceOff(wall15);
Sofia.bounceOff(wall16);
Sofia.bounceOff(wall17);
Sofia.bounceOff(wall18);
Sofia.bounceOff(wall19);
Sofia.bounceOff(wall20);
Sofia.bounceOff(wall21);
Sofia.bounceOff(wall22);
}

function checkwin()
{
  if ( Sofia.isTouching(cup))  
{
  textSize(100);
  stroke("red");
  text("You Win", 200,200);
  }
}























// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
